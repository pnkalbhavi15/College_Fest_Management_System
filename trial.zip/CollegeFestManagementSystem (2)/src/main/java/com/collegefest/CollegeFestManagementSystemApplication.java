package com.collegefest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CollegeFestManagementSystemApplication {
    public static void main(String[] args) {
        SpringApplication.run(CollegeFestManagementSystemApplication.class, args);
    }
}